# �� �ݒ�t�@�C���ǂݍ���
$configPath = "C:\WeatherSystem\Config\dbconfig.json"
$config = Get-Content $configPath | ConvertFrom-Json

# �� DB�ڑ�������
$connectionString = "Server=$($config.Server);Database=$($config.Database);User ID=$($config.User);Password=$($config.Password);"

# �� OpenWeatherMap API�L�[
$apiKey = $config.OpenWeatherApiKey

# �� ���O�t�@�C���ݒ�
$logDir = "C:\WeatherSystem\Logs"
if (!(Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }

$logFile = "$logDir\update_city_{0}.log" -f (Get-Date -Format "yyyyMMdd")

function Write-Log($message) {
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    "$timestamp  $message" | Out-File -FilePath $logFile -Append -Encoding UTF8
}

Write-Log "=== UpdateCityMaster ���s�J�n ==="

# �� CSV �ǂݍ���
$csvPath = "C:\WeatherSystem\Data\cities.csv"
$csv = Import-Csv $csvPath
Write-Log "CSV�Ǎ�: $csvPath"
Write-Log "�s�s��: $($csv.Count)"

# �� API�Ăяo���J�E���^
$callCount = 0

try {
    # �� DB�ڑ�
    $connection = New-Object System.Data.SqlClient.SqlConnection($connectionString)
    $connection.Open()
    Write-Log "DB�ڑ�����"

    foreach ($row in $csv) {

        Write-Log "�s�s�����J�n: $($row.CityEn)"

        # �� �����`�F�b�N
        $checkCmd = $connection.CreateCommand()
        $checkCmd.CommandText = "
            SELECT COUNT(*) FROM CityMaster WHERE CityCode = '$($row.CityCode)'
        "
        $exists = $checkCmd.ExecuteScalar()

        if ($exists -eq 0) {
            Write-Log "�V�K�o�^: $($row.CityCode) $($row.CityEn)"

            $insertCmd = $connection.CreateCommand()
            $insertCmd.CommandText = "
                INSERT INTO CityMaster (CityCode, CityEn, CityJp, CountryCode)
                VALUES ('$($row.CityCode)', '$($row.CityEn)', N'$($row.CityJp)', '$($row.CountryCode)')
            "
            $insertCmd.ExecuteNonQuery()
        }
        else {
            Write-Log "�����f�[�^: $($row.CityCode)"

            # �� CountryCode �� NULL �̏ꍇ�͍X�V
            $countryCmd = $connection.CreateCommand()
            $countryCmd.CommandText = "
                UPDATE CityMaster
                SET CountryCode = '$($row.CountryCode)'
                WHERE CityCode = '$($row.CityCode)' AND (CountryCode IS NULL OR CountryCode = '')
            "
            $countryCmd.ExecuteNonQuery()
        }

        # �� �ܓx�o�x�`�F�b�N
        $geoCmd = $connection.CreateCommand()
        $geoCmd.CommandText = "
            SELECT Latitude, Longitude FROM CityMaster WHERE CityCode = '$($row.CityCode)'
        "
        $reader = $geoCmd.ExecuteReader()
        $reader.Read()
        $lat = $reader["Latitude"]
        $lon = $reader["Longitude"]
        $reader.Close()

        if ($lat -ne $null -and $lon -ne $null) {
            Write-Log "�ܓx�o�x�o�^�ς� �� �X�L�b�v"
            continue
        }

        # �� API�Ăяo�������`�F�b�N
        if ($callCount -ge 60) {
            Write-Log "API�Ăяo��60�� �� 1���ҋ@"
            Start-Sleep -Seconds 60
            $callCount = 0
        }

        # �� �ܓx�o�x�擾
        $geoUrl = "http://api.openweathermap.org/geo/1.0/direct?q=$($row.CityEn)&limit=1&appid=$apiKey"
        Write-Log "Geocoding API �Ăяo��: $geoUrl"

        $geo = Invoke-RestMethod -Uri $geoUrl -Method Get
        $callCount++
        Start-Sleep -Milliseconds 1200

        if ($geo.Count -gt 0) {
            $lat = $geo[0].lat
            $lon = $geo[0].lon

            Write-Log "�ܓx�o�x�擾����: lat=$lat lon=$lon"

            $updateCmd = $connection.CreateCommand()
            $updateCmd.CommandText = "
                UPDATE CityMaster
                SET Latitude = $lat, Longitude = $lon
                WHERE CityCode = '$($row.CityCode)'
            "
            $updateCmd.ExecuteNonQuery()

            Write-Log "�ܓx�o�x�X�V����: $($row.CityCode)"
        }
        else {
            Write-Log "�ܓx�o�x�擾���s: $($row.CityEn)"
        }
    }

    $connection.Close()
    Write-Log "DB�ڑ��I��"

}
catch {
    Write-Log "�G���[����: $_"
}

Write-Log "=== UpdateCityMaster ���s�I�� ==="
