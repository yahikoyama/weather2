# ================================
# Weekly Weather Summary Generator
# ================================

$configPath = "C:\weather\config\dbconfig.json"
$config = Get-Content $configPath | ConvertFrom-Json

$server   = $config.Server
$database = $config.Database
$user     = $config.User
$password = $config.Password

$sql = @"
DECLARE @Now DATE = CAST(GETDATE() AS DATE);

-- ���T�̌��j
DECLARE @ThisMonday DATE = DATEADD(WEEK, DATEDIFF(WEEK, 0, @Now), 0);

-- �O�T�̌��j
DECLARE @FromDate DATE = DATEADD(WEEK, -1, @ThisMonday);

-- �O�T�̓��j
DECLARE @ToDate DATE = DATEADD(DAY, 6, @FromDate);

-- �� �ꎞ�e�[�u���i�W�v���ʂ��ɍ��j
DECLARE @temp TABLE (
    CityCode VARCHAR(10),
    AvgTemperature DECIMAL(5,2),
    AvgHumidity DECIMAL(5,2),
    DI DECIMAL(5,2)
);

-- �� �܂��W�v���� @temp �ɓ����
INSERT INTO @temp
SELECT
    W.CityCode,
    AVG(W.Temperature),
    AVG(W.Humidity),
    (
        0.81 * AVG(W.Temperature)
        + 0.01 * AVG(W.Humidity) * (0.99 * AVG(W.Temperature) - 14.3)
        + 46.3
    ) AS DI
FROM WeatherLog W
WHERE W.LogDate BETWEEN @FromDate AND @ToDate
GROUP BY W.CityCode;

-- �� ComfortLevel �� JOIN ���� WeeklyWeatherSummary �ɓo�^
INSERT INTO WeeklyWeatherSummary (
    CityCode,
    AvgTemperature,
    AvgHumidity,
    DiscomfortIndex,
    ComfortLevel,
    FromDate,
    ToDate,
    Term
)
SELECT
    T.CityCode,
    T.AvgTemperature,
    T.AvgHumidity,
    T.DI,
    CL.LevelName,
    @FromDate,
    @ToDate,
    '1w'
FROM @temp T
JOIN ComfortLevel CL
    ON T.DI BETWEEN CL.MinDI AND CL.MaxDI
WHERE NOT EXISTS (
    SELECT 1
    FROM WeeklyWeatherSummary S
    WHERE S.CityCode = T.CityCode
      AND S.FromDate = @FromDate
      AND S.ToDate = @ToDate
      AND S.Term = '1w'
);
"@

sqlcmd -S $server -d $database -U $user -P $password -Q $sql

Write-Host "Weekly summary calculation completed."
