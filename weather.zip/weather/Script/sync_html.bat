PowerShell -ExecutionPolicy RemoteSigned ./sync_html.ps1
