# -*- coding: utf-8 -*-
import pyodbc
import json

# ▼ JSON 読み込み（DB設定）
with open(r"C:\weather\Config\dbconfig.json", "r", encoding="utf-8") as f:
    config = json.load(f)

SERVER = config["Server"]
DATABASE = config["Database"]
USER = config["User"]
PASSWORD = config["Password"]

# ▼ SQL（JP）
SQL_JP = """
WITH LatestLog AS (
    SELECT wl.*
    FROM WeatherLog wl
    INNER JOIN (
        SELECT CityCode, MAX(CreatedAt) AS MaxCreatedAt
        FROM WeatherLog
        GROUP BY CityCode
    ) x
        ON wl.CityCode = x.CityCode
       AND wl.CreatedAt = x.MaxCreatedAt
)
SELECT
    REPLACE(REPLACE(c.CityJp, '(', ''), ')', '') AS 地名,
    l.Temperature AS 温度,
    l.Humidity AS 湿度,
    w.WeatherNameJp AS 天気,
    FORMAT(l.CreatedAt, 'yyyy-MM-dd HH:mm:ss') AS 取得時間JST
FROM LatestLog l
INNER JOIN CityMaster c ON l.CityCode = c.CityCode
INNER JOIN WeatherCodeMaster w ON l.WeatherCode = w.WeatherCode
WHERE c.CountryCode = 'JP'
ORDER BY l.Temperature ASC;
"""

# ▼ SQL（NOTJP）
SQL_NOTJP = """
WITH LatestLog AS (
    SELECT wl.*
    FROM WeatherLog wl
    INNER JOIN (
        SELECT CityCode, MAX(CreatedAt) AS MaxCreatedAt
        FROM WeatherLog
        GROUP BY CityCode
    ) x
        ON wl.CityCode = x.CityCode
       AND wl.CreatedAt = x.MaxCreatedAt
)
SELECT
    REPLACE(REPLACE(c.CityJp, '(', ''), ')', '') AS 地名,
    l.Temperature AS 温度,
    l.Humidity AS 湿度,
    w.WeatherNameJp AS 天気,
    FORMAT(l.CreatedAt, 'yyyy-MM-dd HH:mm:ss') AS 取得時間JST,
    c.CountryCode AS 国
FROM LatestLog l
INNER JOIN CityMaster c ON l.CityCode = c.CityCode
INNER JOIN WeatherCodeMaster w ON l.WeatherCode = w.WeatherCode
WHERE c.CountryCode <> 'JP'
ORDER BY l.Temperature ASC;
"""

# ▼ DB 接続
conn = pyodbc.connect(
    f"DRIVER={{SQL Server}};SERVER={SERVER};DATABASE={DATABASE};UID={USER};PWD={PASSWORD}"
)
cursor = conn.cursor()

# ▼ JP 取得
cursor.execute(SQL_JP)
rows_jp = cursor.fetchall()

# ▼ NOTJP 取得
cursor.execute(SQL_NOTJP)
rows_notjp = cursor.fetchall()

conn.close()

# ▼ テキスト出力
output_path = r"C:\weather\Output\jp_result.txt"

with open(output_path, "w", encoding="utf-8") as f:

    # ▼ 取得時間（JP の最初の行を採用）
    if len(rows_jp) > 0:
        first_time = rows_jp[0][4]  # 取得時間JST
        f.write(f"取得時間JST {first_time}\n")

    # ▼ JP セクション
    f.write("【国内（JP）】\n")
    f.write("地名, 温度, 湿度, 天気,\n")

    for r in rows_jp:
        r = list(r)
        r.pop(4)  # 取得時間JST を削除
        line = ", ".join([str(x).strip() for x in r]) + ","
        f.write(line + "\n")

    f.write("\n\n")

    # ▼ NOTJP セクション
    f.write("【海外（NOTJP）】\n")
    f.write("地名, 温度, 湿度, 天気, 国,\n")

    for r in rows_notjp:
        r = list(r)
        r.pop(4)  # 取得時間JST を削除
        line = ", ".join([str(x).strip() for x in r]) + ","
        f.write(line + "\n")

print("JP + NOTJP のデータを出力しました:", output_path)
