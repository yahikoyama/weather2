# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc
import json

# ▼ JSON 読み込み
with open(r"C:\weather\Config\dbconfig.json", "r", encoding="utf-8") as f:
    config = json.load(f)

SERVER = config["Server"]
DATABASE = config["Database"]
USER = config["User"]
PASSWORD = config["Password"]

# ▼ 並び順（"ASC" = 寒い順, "DESC" = 暑い順）
sort_order = "ASC"

def get_sql_query():
    return f"""
WITH LatestLog AS (
    SELECT
        wl.*
    FROM WeatherLog wl
    INNER JOIN (
        SELECT CityCode, MAX(CreatedAt) AS MaxCreatedAt
        FROM WeatherLog
        GROUP BY CityCode
    ) x
        ON wl.CityCode = x.CityCode
       AND wl.CreatedAt = x.MaxCreatedAt
)
SELECT
    REPLACE(REPLACE(c.CityJp, '(', ''), ')', '') AS 地名,
    l.Temperature AS 温度,
    l.Humidity AS 湿度,
    w.WeatherNameJp AS 天気,
    FORMAT(l.CreatedAt, 'yyyy-MM-dd HH:mm:ss') AS 取得時間JPN
FROM LatestLog l
INNER JOIN CityMaster c
    ON l.CityCode = c.CityCode
INNER JOIN WeatherCodeMaster w
    ON l.WeatherCode = w.WeatherCode
ORDER BY l.Temperature {sort_order};
"""

# ▼ DB からデータ取得
def fetch_data():
    try:
        conn = pyodbc.connect(
            f"DRIVER={{SQL Server}};"
            f"SERVER={SERVER};"
            f"DATABASE={DATABASE};"
            f"UID={USER};"
            f"PWD={PASSWORD}"
        )
        cursor = conn.cursor()
        cursor.execute(get_sql_query())
        rows = cursor.fetchall()
        conn.close()

        # 表をクリア
        for row in tree.get_children():
            tree.delete(row)

        # ▼ 整形して表示
        for r in rows:
            row = list(r)

            row[0] = str(row[0]).replace("(", "").replace(")", "").replace("'", "").replace(",", "").strip()
            row[3] = str(row[3]).replace("'", "").replace(",", "").strip()
            row[4] = str(row[4]).replace("'", "").strip()

            tree.insert("", tk.END, values=row)

    except Exception as e:
        messagebox.showerror("エラー", f"データ取得に失敗しました\n{e}")

# ▼ 寒い順
def sort_cold():
    global sort_order
    sort_order = "ASC"
    fetch_data()

# ▼ 暑い順
def sort_hot():
    global sort_order
    sort_order = "DESC"
    fetch_data()

# ▼ GUI 作成
root = tk.Tk()
root.title("最新気象データビューア")
root.geometry("820x520")

# ▼ ボタン
btn = tk.Button(root, text="最新データ取得", command=fetch_data, font=("Meiryo", 12))
btn.pack(pady=5)

cold_btn = tk.Button(root, text="寒い順に並び替え", command=sort_cold, font=("Meiryo", 12))
cold_btn.pack(pady=5)

hot_btn = tk.Button(root, text="暑い順に並び替え", command=sort_hot, font=("Meiryo", 12))
hot_btn.pack(pady=5)

# ▼ 表（Treeview）
columns = ("地名", "温度", "湿度", "天気", "取得時間JPN")
tree = ttk.Treeview(root, columns=columns, show="headings", height=15)

for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=150)

tree.pack(fill=tk.BOTH, expand=True)

root.mainloop()
