# ============================================
# historical_sitemap_sync.ps1�iGitHub�d�l���S�����Łj
# ============================================

function HtmlEncode {
    param([string]$text)
    $text = $text -replace '&', '&amp;'
    $text = $text -replace '<', '&lt;'
    $text = $text -replace '>', '&gt;'
    $text = $text -replace '"', '&quot;'
    $text = $text -replace "'", '&#39;'
    return $text
}

# --------------------------------------------
# GitHub Token �ǂݍ���
# --------------------------------------------
$configPath = "C:\weather\config\sync.json"
$config = Get-Content -Raw $configPath | ConvertFrom-Json
$token = $config.token

# GitHub ���
$repoOwner = "yahikoyama"
$repoName  = "weather2"
$branch    = "main"
$targetPath = "sitemap.xml"

# ���[�J���t�H���_
$baseDir = "C:\Users\winserverroot\OneDrive\Historical"
$htmlDir = Join-Path $baseDir "html"
$sitemapPath = Join-Path $htmlDir "sitemap.xml"

# --------------------------------------------
# weekly_*.txt �� weekly_*.html
# --------------------------------------------
$weeklyTxtFiles = Get-ChildItem -Path $baseDir -Filter "weekly_*.txt"

foreach ($file in $weeklyTxtFiles) {
    if ($file.BaseName -match "weekly_(\d{8})_(\d{8})") {
        $start = $matches[1]
        $end   = $matches[2]
    } else { continue }

    $outFile = Join-Path $htmlDir ("weekly_{0}_{1}.html" -f $start, $end)
    if (Test-Path $outFile) { continue }

    $content = Get-Content -Path $file.FullName -Raw
    $encoded = HtmlEncode $content

@"
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>Weekly $start-$end</title>
<style>
body { font-family: Consolas, "Meiryo", sans-serif; white-space: pre-wrap; line-height: 1.5; margin: 20px; }
</style>
</head>
<body>
$encoded
</body>
</html>
"@ | Set-Content -Path $outFile -Encoding UTF8
}

# --------------------------------------------
# historical_*.html + weekly_*.html ���\�[�g
# --------------------------------------------
$historicalFiles = Get-ChildItem -Path $htmlDir -Filter "historical_*.html"
$weeklyFiles     = Get-ChildItem -Path $htmlDir -Filter "weekly_*.html"

$allEntries = @()

foreach ($file in $historicalFiles) {
    if ($file.BaseName -match "historical_(\d{8})") {
        $allEntries += [PSCustomObject]@{
            Type = "historical"
            File = $file
            SortKey = $matches[1]
        }
    }
}

foreach ($file in $weeklyFiles) {
    if ($file.BaseName -match "weekly_(\d{8})_(\d{8})") {
        $allEntries += [PSCustomObject]@{
            Type = "weekly"
            File = $file
            SortKey = $matches[1]
        }
    }
}

$sortedEntries = $allEntries | Sort-Object SortKey

# --------------------------------------------
# sitemap.xml ����
# --------------------------------------------
$baseUrl = "https://yahikoyama.github.io/weather2"

$xml = @()
$xml += '<?xml version="1.0" encoding="UTF-8"?>'
$xml += '<urlset xmlns="http://sitemaps.org">'
$xml += '  <url>'
$xml += "    <loc>$baseUrl/</loc>"
$xml += '    <priority>1.0</priority>'
$xml += '  </url>'

foreach ($entry in $sortedEntries) {
    $name = $entry.File.Name
    $url  = "$baseUrl/Historical/$name"
    $priority = if ($entry.Type -eq "weekly") { "0.6" } else { "0.5" }

    $xml += '  <url>'
    $xml += "    <loc>$url</loc>"
    $xml += "    <priority>$priority</priority>"
    $xml += '  </url>'
}

$xml += '</urlset>'

$xml | Set-Content -Path $sitemapPath -Encoding UTF8

Write-Host "���[�J�� sitemap.xml�i�\�[�g�ς݁j�𐶐����܂����B" -ForegroundColor Cyan

# --------------------------------------------
# OneDrive�΍�F���[�J���Ɉꎞ�R�s�[���Ă���ǂݍ���
# --------------------------------------------
$tempPath = "C:\weather\temp_sitemap.xml"
Copy-Item $sitemapPath $tempPath -Force

$localContent = Get-Content $tempPath -Raw

if (-not $localContent) {
    Write-Host "���[�J�� sitemap.xml �̓ǂݍ��݂Ɏ��s���܂����B" -ForegroundColor Red
    exit 1
}

# --------------------------------------------
# GitHub �� sitemap.xml ���擾
# --------------------------------------------
$apiUrl = "https://api.github.com/repos/$repoOwner/$repoName/contents/$targetPath?ref=$branch"

try {
    $remote = Invoke-RestMethod -Uri $apiUrl -Headers @{ Authorization = "token $token" }
    $remoteBase64 = $remote.content
    $remoteSha    = $remote.sha
    Write-Host "GitHub ��� sitemap.xml ���擾���܂����B" -ForegroundColor Cyan
}
catch {
    Write-Host "GitHub ��� sitemap.xml �����݂��܂���i�V�K�쐬�j�B" -ForegroundColor Yellow
    $remoteBase64 = ""
    $remoteSha    = $null
}

# --------------------------------------------
# �����`�F�b�N�iBase64��r �� �ł��m���j
# --------------------------------------------
$localBase64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($localContent))

if ($localBase64 -eq $remoteBase64) {
    Write-Host "�����Ȃ� �� �A�b�v���[�h�s�v" -ForegroundColor Green
    exit 0
}

Write-Host "�������� �� GitHub �ɃA�b�v���[�h���܂�" -ForegroundColor Magenta

# --------------------------------------------
# PUT �A�b�v���[�h�iSHA �K�{ �� GitHub�d�l�j
# --------------------------------------------
$body = @{
    message = "update sitemap.xml"
    content = $localBase64
    branch  = $branch
}

if ($remoteSha) {
    $body.sha = $remoteSha
}

$json = $body | ConvertTo-Json -Depth 10

$result = Invoke-RestMethod -Uri $apiUrl -Method PUT -Headers @{ Authorization = "token $token" } -Body $json

Write-Host "=== GitHub �� sitemap.xml ���A�b�v���[�h���� ===" -ForegroundColor Green
Write-Host "URL: https://github.com/$repoOwner/$repoName/blob/$branch/$targetPath"

# --------------------------------------------
# weekly HTML �� GitHub �� Historical/ �ɃA�b�v���[�h
# --------------------------------------------
Write-Host "weekly HTML �� GitHub �ɃA�b�v���[�h���܂�..." -ForegroundColor Cyan

$weeklyHtmlFiles = Get-ChildItem -Path $htmlDir -Filter "weekly_*.html"

foreach ($file in $weeklyHtmlFiles) {

    $fileName = $file.Name
    $githubPath = "Historical/$fileName"
    $apiUrlWeekly = "https://api.github.com/repos/$repoOwner/$repoName/contents/$githubPath?ref=$branch"

    # ���[�J���t�@�C���ǂݍ���
    $contentRaw = Get-Content -Path $file.FullName -Raw
    $contentBase64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($contentRaw))

    # GitHub ��̃t�@�C���m�F
    $remoteShaWeekly = $null
    try {
        $remoteWeekly = Invoke-RestMethod -Uri $apiUrlWeekly -Headers @{ Authorization = "token $token" }
        $remoteShaWeekly = $remoteWeekly.sha
        Write-Host "$fileName �� GitHub ��ɑ��� �� �X�V���܂�" -ForegroundColor Yellow
    }
    catch {
        Write-Host "$fileName �� GitHub ��ɑ��݂��܂��� �� �V�K�쐬���܂�" -ForegroundColor Magenta
    }

    # PUT �{�f�B
    $bodyWeekly = @{
        message = "update $fileName"
        content = $contentBase64
        branch  = $branch
    }

    if ($remoteShaWeekly) {
        $bodyWeekly.sha = $remoteShaWeekly
    }

    $jsonWeekly = $bodyWeekly | ConvertTo-Json -Depth 10

    # �A�b�v���[�h
    $resultWeekly = Invoke-RestMethod -Uri $apiUrlWeekly -Method PUT -Headers @{ Authorization = "token $token" } -Body $jsonWeekly

    Write-Host "$fileName ���A�b�v���[�h���܂����B" -ForegroundColor Green
}

Write-Host "=== weekly HTML �� GitHub �A�b�v���[�h���� ===" -ForegroundColor Cyan
