# ============================================
# Historical/html/index.html �ɍŐV�T�̃����N��ǉ��i�ŐV����ԏ�j
# ============================================

$baseFolder = "C:\Users\winserverroot\OneDrive\Historical\html"
$indexPath  = Join-Path $baseFolder "index.html"

# ============================================
# weekly_yyyyMMdd_yyyyMMdd.html ���擾
# ============================================

$weeklyFiles = Get-ChildItem -Path $baseFolder -Filter "weekly_*.html"

if ($weeklyFiles.Count -eq 0) {
    Write-Host "No weekly HTML files found in $baseFolder"
    exit
}

# �t�@�C����������t���o
$weeklyList = foreach ($f in $weeklyFiles) {
    if ($f.BaseName -match "weekly_(\d{8})_(\d{8})") {
        [PSCustomObject]@{
            FileName = $f.Name
            FromDate = [datetime]::ParseExact($matches[1], "yyyyMMdd", $null)
            ToDate   = [datetime]::ParseExact($matches[2], "yyyyMMdd", $null)
        }
    }
}

# ============================================
# index.html ��ǂݍ���
# ============================================

$indexText = Get-Content $indexPath -Raw

# <ul> �� </ul> �̈ʒu���^�O�Ō����i�s�ԍ��ł͂Ȃ������ʒu�j
$ulStartPos = $indexText.IndexOf("<ul>")
$ulEndPos   = $indexText.IndexOf("</ul>")

if ($ulStartPos -lt 0 -or $ulEndPos -lt 0) {
    Write-Host "ERROR: <ul> or </ul> not found. index.html is broken."
    exit
}

# <ul> ���̃e�L�X�g�𒊏o
$ulContent = $indexText.Substring($ulStartPos, $ulEndPos - $ulStartPos)

# ������ <li> �𒊏o
$existingLi = Select-String -InputObject $ulContent -Pattern "<li>.*?</li>" -AllMatches |
              ForEach-Object { $_.Matches.Value }

# ============================================
# ������ <li> ���p�[�X���ē��t���o�iFileName �x�[�X�j
# ============================================

$parsedLi = foreach ($line in $existingLi) {
    if ($line -match "weekly_(\d{8})_(\d{8})\.html") {
        [PSCustomObject]@{
            Line     = $line
            FileName = "weekly_$($matches[1])_$($matches[2]).html"
            FromDate = [datetime]::ParseExact($matches[1], "yyyyMMdd", $null)
            ToDate   = [datetime]::ParseExact($matches[2], "yyyyMMdd", $null)
        }
    }
}

# ============================================
# �� �d���`�F�b�N�� FileName �ōs���i��΂ɏd�����Ȃ��j
# ============================================

foreach ($w in $weeklyList) {
    if ($parsedLi.FileName -notcontains $w.FileName) {
        $newLine = "  <li><a href=""$($w.FileName)"">$($w.FileName)</a></li>"
        $parsedLi += [PSCustomObject]@{
            Line     = $newLine
            FileName = $w.FileName
            FromDate = $w.FromDate
            ToDate   = $w.ToDate
        }
    }
}

# ============================================
# �� ���t�Ń\�[�g�i�ŐV����ԏ�j
# ============================================

$sortedLi = $parsedLi | Sort-Object ToDate -Descending

# ============================================
# �V���� <ul> �u���b�N���쐬
# ============================================

$newUlBlock = "<ul>`r`n"
foreach ($item in $sortedLi) {
    $newUlBlock += $item.Line + "`r`n"
}
$newUlBlock += "</ul>"

# ============================================
# index.html ���č\�z�i�^�O�ʒu�Œu���j
# ============================================

$newIndexText = $indexText.Substring(0, $ulStartPos) +
                $newUlBlock +
                $indexText.Substring($ulEndPos + 5)

# �ۑ�
$newIndexText | Out-File -FilePath $indexPath -Encoding UTF8

Write-Host "index.html updated successfully (sorted & deduplicated)."
